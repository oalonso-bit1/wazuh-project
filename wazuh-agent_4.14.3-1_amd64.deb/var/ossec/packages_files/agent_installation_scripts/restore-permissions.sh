#!/bin/sh
chown -- 'wazuh:wazuh' '/var/ossec/queue/syscollector/db'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/syscollector/db'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/queue/syscollector/norm_config.json'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/queue/syscollector/norm_config.json'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/queue/syscollector'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/syscollector'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/queue/alerts'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/queue/alerts'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/queue/sockets'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/queue/sockets'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/queue/fim/db'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/fim/db'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/queue/fim'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/fim'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/queue/rids'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/rids'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/queue/logcollector'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/logcollector'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/queue/diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/diff'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/queue'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/ssh_nopass.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_nopass.exp'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/ssh_foundry_diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_foundry_diff'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/ssh_integrity_check_bsd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_integrity_check_bsd'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/ssh_generic_diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_generic_diff'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/su.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/su.exp'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/ssh.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh.exp'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/ssh_integrity_check_linux'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_integrity_check_linux'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/sshlogin.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/sshlogin.exp'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/register_host.sh'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/register_host.sh'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/ssh_pixconfig_diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_pixconfig_diff'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/ssh_asa-fwsmconfig_diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_asa-fwsmconfig_diff'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless/main.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/main.exp'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/agentless'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/tmp'  > /dev/null 2>&1 || :
chmod 1770 '/var/ossec/tmp'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/ipfw'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/ipfw'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/restart.sh'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/restart.sh'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/kaspersky.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/kaspersky.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/firewalld-drop'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/firewalld-drop'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/default-firewall-drop'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/default-firewall-drop'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/pf'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/pf'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/host-deny'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/host-deny'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/route-null'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/route-null'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/disable-account'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/disable-account'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/npf'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/npf'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/wazuh-slack'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/wazuh-slack'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/restart-wazuh'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/restart-wazuh'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/kaspersky'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/kaspersky'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/ip-customblock'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/ip-customblock'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin/firewall-drop'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/firewall-drop'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response/bin'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/active-response'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/VERSION.json'  > /dev/null 2>&1 || :
chmod 440 '/var/ossec/VERSION.json'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libgcc_s.so.1'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libgcc_s.so.1'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libfimebpf.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libfimebpf.so'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libfimdb.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libfimdb.so'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/librsync.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/librsync.so'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libstdc++.so.6'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libstdc++.so.6'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libsysinfo.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libsysinfo.so'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libwazuhshared.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libwazuhshared.so'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libbpf.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libbpf.so'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libdbsync.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libdbsync.so'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libwazuhext.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libwazuhext.so'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/modern.bpf.o'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/modern.bpf.o'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib/libsyscollector.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libsyscollector.so'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/lib'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/backup'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/backup'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/.ssh'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/.ssh'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/logs/wazuh'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/logs/wazuh'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/logs'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/logs'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/wazuh_integration.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/wazuh_integration.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/services/cloudwatchlogs.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/services/cloudwatchlogs.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/services/inspector.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/services/inspector.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/services/aws_service.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/services/aws_service.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/services/__init__.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/services/__init__.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/services'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/services'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/subscribers/sqs_queue.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/subscribers/sqs_queue.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/subscribers/sqs_message_processor.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/subscribers/sqs_message_processor.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/subscribers/__init__.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/subscribers/__init__.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/subscribers/s3_log_handler.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/subscribers/s3_log_handler.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/subscribers'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/subscribers'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/server_access.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/server_access.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/vpcflow.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/vpcflow.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/waf.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/waf.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/cloudtrail.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/cloudtrail.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/load_balancers.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/load_balancers.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/umbrella.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/umbrella.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/config.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/config.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/aws_bucket.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/aws_bucket.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/guardduty.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/guardduty.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3/__init__.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3/__init__.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/buckets_s3'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/buckets_s3'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/aws-s3'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/aws-s3'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/__init__.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/__init__.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws/aws_tools.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/aws_tools.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/aws'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/utils.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/utils.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/docker/DockerListener'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/docker/DockerListener'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/docker'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/docker'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud/integration.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/integration.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud/buckets/bucket.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/buckets/bucket.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud/buckets/access_logs.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/buckets/access_logs.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud/buckets'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/buckets'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud/gcloud'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/gcloud'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud/exceptions.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/exceptions.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud/pubsub/subscriber.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/pubsub/subscriber.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud/pubsub'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/pubsub'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud/tools.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/tools.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/gcloud'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/db/utils.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/db/utils.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/db/orm.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/db/orm.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/db/__init__.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/db/__init__.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/db'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/db'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/azure_services/graph.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/azure_services/graph.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/azure_services/storage.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/azure_services/storage.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/azure_services/analytics.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/azure_services/analytics.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/azure_services/__init__.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/azure_services/__init__.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/azure_services'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/azure_services'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/azure-logs'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/azure-logs'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure/azure_utils.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure/azure_utils.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/azure'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/azure'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles/__init__.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/__init__.py'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/wodles'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/ruleset/sca/cis_debian7.yml'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/ruleset/sca/cis_debian7.yml'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/ruleset/sca'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/ruleset/sca'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/ruleset'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/ruleset'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/ossec.conf'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/ossec.conf'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/wpk_root.pem'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/wpk_root.pem'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/client.keys'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/client.keys'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/localtime'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/localtime'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/internal_options.conf'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/internal_options.conf'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_win2012r2_memberL1_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_win2012r2_memberL1_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_win2012r2_domainL1_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_win2012r2_domainL1_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/rootkit_files.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/rootkit_files.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_rhel7_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_rhel7_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_win2012r2_domainL2_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_win2012r2_domainL2_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/win_malware_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/win_malware_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_mysql5-6_community_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_mysql5-6_community_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_mysql5-6_enterprise_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_mysql5-6_enterprise_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_sles12_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_sles12_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/win_audit_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/win_audit_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/rootkit_trojans.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/rootkit_trojans.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_apache2224_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_apache2224_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_win2012r2_memberL2_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_win2012r2_memberL2_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/system_audit_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/system_audit_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_rhel5_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_rhel5_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_rhel6_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_rhel6_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/system_audit_ssh.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/system_audit_ssh.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_sles11_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_sles11_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_rhel_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_rhel_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/cis_debian_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_debian_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared/win_applications_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/win_applications_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/shared'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/etc/shared'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/etc/local_internal_options.conf'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/local_internal_options.conf'  > /dev/null 2>&1 || :
chown -- 'wazuh:wazuh' '/var/ossec/etc'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/etc'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/manage_agents'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/manage_agents'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-logcollector'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-logcollector'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-execd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-execd'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-agentd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-agentd'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/agent-auth'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/agent-auth'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-control'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-control'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-modulesd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-modulesd'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-syscheckd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-syscheckd'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/var/selinux/wazuh.pp'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/var/selinux/wazuh.pp'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/var/selinux'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/selinux'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/var/incoming'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/incoming'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/var/upgrade'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/upgrade'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/var/wodles'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/wodles'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/var/run'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/run'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/var'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/var'  > /dev/null 2>&1 || :
chown -- 'root:wazuh' '/var/ossec/'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/'  > /dev/null 2>&1 || :
